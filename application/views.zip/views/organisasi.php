<!DOCTYPE html>
<html lang="en">
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->
    <!-- Hero Section Start -->
    <div class="container-m-1 py-1 bg-white hero-header mb-4">
        <div class="container my-5 py-5">
            <div class="row align-items-center g-5">
                <div class="col-lg-6 text-center text-lg-start">
                    <h1 class="display-3 text-dark animated slideInLeft">Sususan Organisasi Desa Tempurharjo</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero Section End -->
<!-- Card Section Start -->
<div class="container my-4">
    <div class="row">
        <!-- Kepala Desa Card -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="<?=base_url('asset/img/TEGAR.png')?>" class="card-img-top" alt="Kepala Desa Image">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Kepala Desa</h5>
                            <p class="card-text">Nama: Alfiyan Tegar</p>
                            <p class="card-text">Tempat, Tanggal Lahir: Solo</p>
                            <p class="card-text">Alamat: Solo</p>
                            <p class="card-text">Pendidikan: udb.com</p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>

        <!-- Sekretaris Card -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="<?=base_url('asset/img/EGA.png')?>" class="card-img-top" alt="Sekretaris Image">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Sekretaris Desa</h5>
                            <p class="card-text">Nama: Ega goat</p>
                            <p class="card-text">Tempat, Tanggal Lahir: 33</p>
                            <p class="card-text">Alamat: Kandang</p>
                            <p class="card-text">Pendidikan: suket.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Kaur Pemerintah Card -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="<?=base_url('asset/img/STEFAN.png')?>" class="card-img-top" alt="Kaur Pemerintah Image">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Kaur Pemerintah</h5>
                            <p class="card-text">Nama: Step</p>
                            <p class="card-text">Tempat, Tanggal Lahir: solo</p>
                            <p class="card-text">Alamat: langkah</p>
                            <p class="card-text">Pendidikan: steppp.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bendahara Desa Card -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="<?=base_url('asset/img/RENDY.png')?>" class="card-img-top" alt="Bendahara Image">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Bendahara Desa</h5>
                            <p class="card-text">Nama: Rendy</p>
                            <p class="card-text">Tempat, Tanggal Lahir: solo</p>
                            <p class="card-text">Alamat: solo</p>
                            <p class="card-text">Pendidikan: udb.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- kaur Kesra/Kesos Card -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="<?=base_url('asset/#')?>" class="card-img-top" alt="Kaur kesra/kesos Image">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">kaur Kesra/Kesos</h5>
                            <p class="card-text">Nama: John Doe</p>
                            <p class="card-text">Tempat, Tanggal Lahir: John Doe</p>
                            <p class="card-text">Alamat: John Doe</p>
                            <p class="card-text">Pendidikan: john.doe@example.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- kaur ekbang Card -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="<?=base_url('asset/#')?>" class="card-img-top" alt="Kaur Ekbang Image">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">kaur ekbang</h5>
                            <p class="card-text">Nama: John Doe</p>
                            <p class="card-text">Tempat, Tanggal Lahir: John Doe</p>
                            <p class="card-text">Alamat: John Doe</p>
                            <p class="card-text">Pendidikan: john.doe@example.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- kadus Card -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="<?=base_url('asset/#')?>" class="card-img-top" alt="Kadus Image">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Kadus</h5>
                            <p class="card-text">Nama: John Doe</p>
                            <p class="card-text">Tempat, Tanggal Lahir: John Doe</p>
                            <p class="card-text">Alamat: John Doe</p>
                            <p class="card-text">Pendidikan: john.doe@example.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        

        <!-- Add more cards as needed -->

    </div>
</div>
<!-- Card Section End -->


        <!-- Add more cards as needed -->

    </div>
</div>
<!-- Card Section End -->

    
                <!-- Add more cards as needed -->
    
            </div>
        </div>
        <!-- Card Section End -->
</html>
