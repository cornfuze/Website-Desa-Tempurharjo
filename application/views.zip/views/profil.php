<!DOCTYPE html>
<html lang="en">
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->
    <!-- Hero Section Start -->
    <div class="container-m-1 py-1 bg-white hero-header mb-4">
        <div class="container my-5 py-5">
            <div class="row align-items-center g-5">
                <div class="col-lg-6 text-center text-lg-start">
                    <h1 class="display-3 text-dark animated slideInLeft">Profil<br>Desa Tempurharjo</h1>
                    <p class="text-dark animated slideInLeft mb-4 pb-2">Tempurharjo adalah desa di Kecamatan Eromoko,<br>
                        Kabupaten Wonogiri, provinsi Jawa Tengah, Indonesia. Desa<br>
                        ini berjarak sekitar 8 Km dari pusat kecamatan Eromoko<br>
                        atau 25 Km ke arah barat daya dari ibu kota Kabupaten Wonogiri.<br><br>
                        Batas-batas wilayahnya :<br>
                        1. Utara Kecamatan Manyaran dan Kecamatan Wuryantoro.<br>
                        2. Timur Kecamatan Wuryantoro.<br>
                        3. Selatan Desa Pasekan dan Desa Eromoko.<br>
                        4. Barat Desa Ngandong.<br><br>
                        Tempurharjo terbagi menjadi 10 dusun yaitu :<br>
                        1. Dusun Bokuning Kidul<br>
                        2. Dusun Bokuning Lor<br>
                        3. Dusun Dunggupit<br><br>
                        Secara astronomis, Desa tempurharjo terletak pada 7○ 54,25’<br>
                        LS sampai 7○ 56,60’ LS dan 110○ 47,70’ BT sampai 110○ 49,50’<br>
                        BT. Desa Tempurharjo terletak di bagian utara kecamatan Eromoko.<br> 
                        Wilayahnya berada di wilayah dataran tinggi dengan ketinggian<br> 
                        antara 250-600 meter diatas permukaan air laut mdpl terutama<br> 
                        bagian barat yang merupakan lereng perbukitan Gunung Petung.<br> 
                        Terdapat Kali Tukluk atau Sungai Parangjoho yang membelah desa ini.<br>
                        </p>
                </div>
                <div class="col-lg-6 text-center text-lg-end overflow-hidden">
                    <img class="img-fluid" src="<?=base_url('asset/img/Map.png')?>" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Hero Section End -->
</html>
