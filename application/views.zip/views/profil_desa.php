<!DOCTYPE html>
<html lang="en">
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->
    <!-- Hero Section Start -->
    <div class="container-m-1 py-1 bg-white hero-header mb-4">
        <div class="container my-5 py-5">
            <div class="row align-items-center g-5">
                <div class="col-lg-6 text-center text-lg-start">
                    <h1 class="display-3 text-dark animated slideInLeft">Profil<br>Dusun Bokuning Lor</h1>
                    <p class="text-dark animated slideInLeft mb-4 pb-2">Tempurharjo adalah desa di Kecamatan Eromoko, <br>
                        Kabupaten Wonogiri, provinsi Jawa Tengah, Indonesia.<br>
                        Desa ini berjarak sekitar 8 Km dari pusat kecamatan Eromoko <br>
                        atau 25 Km ke arah barat daya dari ibu kota Kabupaten Wonogiri.

                </div>
                <div class="col-lg-6 text-center text-lg-end overflow-hidden">
                    <img class="img-fluid" src="<?=base_url('asset/img/Map.png')?>" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Hero Section End -->
</html>
