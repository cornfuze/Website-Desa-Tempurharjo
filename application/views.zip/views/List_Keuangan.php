<!-- Hero Section Start -->
    <div class="container-m-1 py-1 bg-white hero-header mb-4">
        <div class="container my-5 py-5">
            <div class="row align-items-center g-5">
                <div class="col-lg-6 text-center text-lg-start">
                    <h1 class="display-3 text-dark animated slideInLeft">Keuangan Desa Tempurharjo</h1>
                </div>
            </div>
        </div>
    </div>

    <div>
        <div class="row">
            <div class="col-sm-6">
              <div class="card">
                <div class="card-body" style="text-align: center;">
                  <h5 class="card-title"><a href="<?=base_url('home/RPJM')?>" class="nav-item nav-link"> RPJM DESA</a></h5>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="card">
                <div class="card-body" style="text-align: center;">
                  <h5 class="card-title"><a href="<?=base_url('home/RKP')?>" class="nav-item nav-link"> RKP DESA</a></h5>
                </div>
              </div>
            </div>
          </div>
        </div>

    </div>
<br>
    <div>
        <div class="row">
            <div class="col-sm-6">
              <div class="card">
                <div class="card-body" style="text-align: center;">
                  <h5 class="card-title"><a href="<?=base_url('home/APBD')?>" class="nav-item nav-link"> APB DESA</a></h5>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="card">
                <div class="card-body" style="text-align: center;">
                  <h5 class="card-title"><a href="<?=base_url('home/LRA')?>" class="nav-item nav-link"> Laporan Realisasi Anggaran</a></h5>
                </div>
              </div>
            </div>
          </div>
        </div>

    </div>
    <!-- Hero Section End -->