<!DOCTYPE html>
<html lang="en">
    
    <!-- Hero Section Start -->
    <div class="container-m-1 py-1 bg-white hero-header mb-4">
        <div class="container my-5 py-5">
            <div class="row align-items-center g-5">
                <div class="col-lg-6 text-center text-lg-start">
                    <h1 class="display-3 text-dark animated slideInLeft">Berita Desa Tempurharjo</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero Section End -->
    <!-- Card Section Start -->
<div class="container my-4">
    <div class="row">
        <?php foreach($berita as $a):?>
        <!-- Card -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="<?=base_url($a['gambar'])?>" class="card-img-top" alt="Kepala Desa Image">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title"><?=$a['keterangan']?></h5>
                            <p class="card-text">#<?=$a['jenis_kegiatan']?></p>
                            <p class="card-text"><?=$a['tanggal']?></p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- Add more cards as needed -->
        <?php endforeach?>

    </div>
</div>
<!-- Card Section End -->